
<!DOCTYPE html>
<html>
<body>

<h3>Start typing a name in the input field below:</h3>

<form action=""> 

<p>Jornada:
<select id="jornada" name="jornada" onchange="showHint()"> 
<?php 
	
	for ($j=1; $j <= 38; $j++)
	{
		echo "<option value='".$j."'>Jornada ".$j."</option>"; 
	}
   ?>
</select>

</form>



<p>Suggestions: <span id="txtHint"></span></p> 

<script>
function showHint() {
  var xhttp;
    var jornada =  document.getElementById("jornada").value;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "showResults.php?j=" + jornada, true);
  xhttp.send();   
}
</script>

</body>
</html>
