<?php 
/*
Copiar archivo FootballData.php en el directorio:
 /opt/lampp/htdocs/wordpress/wp-includes/
 sudo chown daemon:daemon /opt/lampp/htdocs/wordpress/wp-includes/FootballData.php
*/
require_once "./FootballData.php"; 



   $api = new FootballData();
      $jornada = $_REQUEST["j"];
	 // echo "algo".$jornada;
	 ?>
	 <?php
  echo "<p><hr><p>"; ?>
               <?php echo "<h3>Partidos para la ".  $jornada . " jornada de La Liga</h3>"; ?>
                <table class="table table-striped">
                    <tr>
                    <th>Local</th>
                    <th></th>
                    <th>Visitante</th>
                    <th colspan="3">Resultado</th>
                    </tr>
   
   <?php 
      
   foreach ($api->findMatchesByCompetitionAndMatchday(2014, $jornada)->matches as $match) { ?>
                    <tr>
                        <td><?php echo $match->homeTeam->name; ?></td>
                        <td>-</td>
                        <td><?php echo $match->awayTeam->name; ?></td>
                        <td><?php echo $match->score->fullTime->homeTeam;  ?></td>
                        <td>:</td>
                        <td><?php echo $match->score->fullTime->awayTeam;  ?></td>
                    </tr>
                    <?php } ?>
	   
	   
   </table>

